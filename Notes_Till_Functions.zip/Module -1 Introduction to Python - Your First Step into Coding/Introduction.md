	CPU -> Brain
	
	High Level,
	Interpreted 
	Dynamically Typed Language
	
	## 1. What is Machine Code? (0s and 1s)
	BARCODE -> HUMAN READABLE FORM 
	
	
	- **Definition**: Machine code is the **native language of a computer’s CPU**. It consists of only **0s and 1s (binary numbers)**.
	    
	- Example:
	    
	    `10110000 01100001 10110010 01000010`
	    
	- **Analogy**: Think of machine code as a **barcode** on retail products. Computers scan it and understand it directly, but for humans it’s meaningless.
	    
	
	---
	
	## 2. What is Assembly Language? (Low-Level Language)
	
	- **Assembly**: A slightly human-readable version of machine code. Uses short keywords instead of pure 0s and 1s.
	    
	- Example:
	    
	    `MOV A, 5 ADD A, 2`
	    
	- This means → Move 5 into register A, then add 2.
	    
	- **Analogy**: Like **short codes in retail warehouses**. Instead of remembering 20-digit product codes, staff use short codes like “PRD123”. Still close to the machine.
	    
	
	---
	
	## 3. What is a High-Level Language?
	
	- High-level languages (Python, Java, C++) are **human-friendly**. You write instructions in English-like syntax.
	    2 + 5 
	- Example (Python):
	    
	    `a = 5 b = 2 print(a + b)   # Output: 7`
	    
	- **Analogy**: In retail, imagine an **online POS system** where the cashier clicks “Add Item” instead of remembering product codes. Much easier for humans.
	    
	
	---
	
	## 4. Translation Process
	
	Computers only understand **machine code (0s and 1s)**.  
	High-level code must be translated → Machine code.
	
	### Steps in Python
	
	1. **Source Code** (`.py`) → You write this.
	    
	2. **Bytecode** (`.pyc`) → Python translates source into intermediate form.
	    
	3. **Python Virtual Machine (PVM)** → Executes bytecode as machine instructions.
	    
	
	---
	
	## 5. High-Level vs Low-Level vs Machine Code
	
	| Level               | Example Syntax      | Who Understands It                      | Analogy (Retail)         |
	| ------------------- | ------------------- | --------------------------------------- | ------------------------ |
	| Machine Code        | `10110000 01100001` | CPU only                                | Barcodes                 |
	| Assembly (Low)      | `MOV A, 5`          | CPU + Specialist                        | Short codes in warehouse |
	| High-Level (Python) | `a = 5; print(a)`   | Humans + CPU (via compiler/interpreter) | POS screen “Add Item”    |
	
	---
	
	Compiled 
	Interpreted Language
	## 6. Compilers vs Interpreters
	
	- **Compiler**: Translates entire program into machine code first, then runs it. Faster execution. Example → Java, C++.
	    
	- **Interpreter**: Reads and executes line by line. Slower, but easier debugging. Example → Python.
	larger community 
	    
	easy to write and read 
	
	Syntax -> Set of rules when writing the code -> less time
	Business Logic -> solution you are achvieign by usign the code -> more effort 
	
	Faster Development 
	
	- **Analogy**:
	    
	    - Compiler = Translate **entire novel into another language** before reading.
	- Russian -> Traslating -> English (read)
	- Translater -> Is making mistakes
	        
	    - Interpreter = Translate **sentence by sentence while reading aloud**.
	        
	
	---
	
	## 7. Why Python is High-Level
	
	- Simple English-like syntax.
	    
	- Example:
	    
	    `sales = 100 discount = 10 print(sales - discount)`
	    
	    _You don’t worry about registers, memory, or machine instructions. Python handles it._
	    
	
	---
	
	## 8. Garbage Collection (Beginner Explanation)
	
	- When we create variables, Python allocates memory.
	    
	- When no longer needed, memory is **automatically freed**.
	    
	- **Analogy**: In retail stores, staff clean empty shelves automatically without you asking.
	    
	
	---
	
	## 9. Why Python is Popular
	
	- Easy to learn.
	    
	- Works on all platforms.
	    
	- Large libraries (Pandas, NumPy, PySpark).
	    
	- Widely used in **retail, banking, AI, web apps**.
	    
	- **Retail Example**: Daily **inventory reconciliation** script in Python → 20 lines of code. In C++, maybe 200 lines.
	    
	
	---
	
	## 10. Example Walkthrough for Class
	
	### Code:
	
	`a = 10 b = 20 name = 'Harsha' print(name * b)`
	
	### Teaching Flow:
	
	1. `a = 10` → store value 10 in variable `a`.
	    
	2. `b = 20` → store 20 in variable `b`.
	    
	3. `name = 'Harsha'` → string variable.
	    
	4. `print(name * b)` → repeats `"Harsha"` 20 times.
	    
	
	**Retail Twist**:
	
	`product = "Apple" quantity = 5 print(product * quantity)  # AppleAppleAppleAppleApple`
	
	_This is like printing product labels multiple times for stock._1
	
	
	
	easy 
	easy read 
	easy to learn 
	easy to debug 
	
	disadv:
	slower 
	
	
	
	IDE -> Vs Code 
	Python